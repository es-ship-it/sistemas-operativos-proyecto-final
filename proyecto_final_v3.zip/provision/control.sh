#!/usr/bin/env bash     
set -e       # indica que se usará bash para ejecutar este script y detiene la ejecución si ocurre un error
export DEBIAN_FRONTEND=noninteractive         #evitar preguntas interactivas durante la instalacion de paquetes

# 1) paquetes base
apt-get update -y         # actualizar lista de paquetes  (-y evita confirmaciones)
apt-get install -y --no-install-recommends software-properties-common wget        # instalar paquetes necesarios

# 2) instalar ansible
apt-add-repository --yes --update ppa:ansible/ansible       # agrega repositorio oficial de ansible
apt-get update -y                         # actualizar lista de paquetes
apt-get install -y --no-install-recommends ansible      # instala ansible (solo lo necesario sin paquetes recomendados)

# 3) crear carpeta de llaves 
mkdir -p /home/vagrant/.ssh/vagrant_keys     # carpeta llamada vagrant_keys dentro del directorio .ssh del usuario vagrant

# Copiar las llaves de Vagrant fuera de /vagrant
cp /vagrant/.vagrant/machines/monitor/virtualbox/private_key /home/vagrant/.ssh/vagrant_keys/monitor_key # copiar llave privada de la VM monitor  y la guarda como monitor_key en el directorio de claves SSH
cp /vagrant/.vagrant/machines/webserver/virtualbox/private_key /home/vagrant/.ssh/vagrant_keys/web_key        # copiar llave privada generada por vagrant para la mv webserver
chmod 600 /home/vagrant/.ssh/vagrant_keys/*           # ajustar permisos de las llaves privadas (lectura y escritura solo para el propietario) si no se hace esto, SSH se negará a usar las llaves por razones de seguridad

# ajustar propietario
chown -R vagrant:vagrant /home/vagrant/.ssh/vagrant_keys        # cambiar propietario de la carpeta y su contenido al usuario y grupo vagrant

# 4) crear inventario de Ansible apuntando a estas llaves
#mkdir -p /vagrant/ansible
#cat > /vagrant/ansible/inventory.ini <<'EOF'
#[monitor]
#192.168.56.101 ansible_user=vagrant ansible_ssh_private_key_file=/home/vagrant/.ssh/vagrant_keys/monitor_key

#[web]
#192.168.56.102 ansible_user=vagrant ansible_ssh_private_key_file=/home/vagrant/.ssh/vagrant_keys/web_key

#[all:vars]
#ansible_ssh_common_args='-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null'
#EOF

# inventario de ansible: define hosts, usuarios SSH y llaves
# monitor - servidores de monitoreo
# web - servidores web
# all:vars - variables comunes para todos los hosts


# 5) ejecuta el playbook de Ansible
ansible-playbook /vagrant/provision/playbook.yml -i /vagrant/provision/inventory.ini