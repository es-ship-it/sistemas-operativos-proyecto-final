#!/usr/bin/env bash
set -e
export DEBIAN_FRONTEND=noninteractive

# 1) Paquetes base
apt-get update -y
apt-get install -y --no-install-recommends software-properties-common wget

# 2) Instalar Ansible
apt-add-repository --yes --update ppa:ansible/ansible
apt-get update -y
apt-get install -y --no-install-recommends ansible

# 3) Crear carpeta de llaves 
mkdir -p /home/vagrant/.ssh/vagrant_keys

# Copiar las llaves de Vagrant fuera de /vagrant
cp /vagrant/.vagrant/machines/monitor/virtualbox/private_key /home/vagrant/.ssh/vagrant_keys/monitor_key
cp /vagrant/.vagrant/machines/webserver/virtualbox/private_key /home/vagrant/.ssh/vagrant_keys/web_key
chmod 600 /home/vagrant/.ssh/vagrant_keys/*

# Ajustar propietario
chown -R vagrant:vagrant /home/vagrant/.ssh/vagrant_keys

# 4) Crear inventario de Ansible apuntando a estas llaves
mkdir -p /vagrant/ansible
cat > /vagrant/ansible/inventory.ini <<'EOF'
[monitor]
192.168.56.101 ansible_user=vagrant ansible_ssh_private_key_file=/home/vagrant/.ssh/vagrant_keys/monitor_key

[web]
192.168.56.102 ansible_user=vagrant ansible_ssh_private_key_file=/home/vagrant/.ssh/vagrant_keys/web_key

[all:vars]
ansible_ssh_common_args='-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null'
EOF
