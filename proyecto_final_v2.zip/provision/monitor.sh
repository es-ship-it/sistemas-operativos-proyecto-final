#!/usr/bin/env bash
set -e
export DEBIAN_FRONTEND=noninteractive


# 1) Dependencias básicas

apt-get update -y
apt-get install -y --no-install-recommends wget curl tar gnupg apt-transport-https ca-certificates


# 2) Instalar Prometheus

PROM_VERSION="2.48.0"
PROM_TARBALL="prometheus-${PROM_VERSION}.linux-amd64.tar.gz"
PROM_URL="https://github.com/prometheus/prometheus/releases/download/v${PROM_VERSION}/${PROM_TARBALL}"

useradd --no-create-home --shell /usr/sbin/nologin prometheus || true
mkdir -p /etc/prometheus /var/lib/prometheus

cd /tmp
if [ ! -f /tmp/${PROM_TARBALL} ]; then
  wget -q ${PROM_URL} -O /tmp/${PROM_TARBALL}
fi

tar xzf /tmp/${PROM_TARBALL} -C /tmp
PROMDIR=$(tar -tf /tmp/${PROM_TARBALL} | head -1 | cut -f1 -d"/")

cp /tmp/${PROMDIR}/prometheus /usr/local/bin/
cp /tmp/${PROMDIR}/promtool /usr/local/bin/
cp -r /tmp/${PROMDIR}/consoles /etc/prometheus/
cp -r /tmp/${PROMDIR}/console_libraries /etc/prometheus/


# 3) Configuración de Prometheus

cat > /etc/prometheus/prometheus.yml <<'EOF'
global:
  scrape_interval: 15s

scrape_configs:
  - job_name: 'prometheus'
    static_configs:
      - targets: ['localhost:9090']

  - job_name: 'node_exporter'
    static_configs:
      - targets: ['192.168.56.102:9100']
EOF

chown -R prometheus:prometheus /etc/prometheus /var/lib/prometheus
chmod +x /usr/local/bin/prometheus /usr/local/bin/promtool


# 4) Servicio systemd de Prometheus

cat > /etc/systemd/system/prometheus.service <<'EOF'
[Unit]
Description=Prometheus Monitoring
Wants=network-online.target
After=network-online.target

[Service]
User=prometheus
Group=prometheus
Type=simple
ExecStart=/usr/local/bin/prometheus \
  --config.file=/etc/prometheus/prometheus.yml \
  --storage.tsdb.path=/var/lib/prometheus

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable prometheus
systemctl restart prometheus


# 5) Instalar Grafana

wget -q -O - https://packages.grafana.com/gpg.key | apt-key add - || true
echo "deb https://packages.grafana.com/oss/deb stable main" > /etc/apt/sources.list.d/grafana.list
apt-get update -y
apt-get install -y --no-install-recommends grafana

systemctl daemon-reload
systemctl enable grafana-server
systemctl restart grafana-server

