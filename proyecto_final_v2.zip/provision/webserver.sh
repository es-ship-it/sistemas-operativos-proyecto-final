#!/usr/bin/env bash
set -e
export DEBIAN_FRONTEND=noninteractive


# 1) Instalar Nginx

apt-get update -y
apt-get install -y --no-install-recommends nginx wget

# Pagina web simple
cat > /var/www/html/index.html <<'EOF'
<html>
  <body>
    <h1>Nginx en vagrant-webserver</h1>
    <p>IP: 192.168.56.102</p>
  </body>
</html>
EOF

systemctl enable nginx
systemctl restart nginx


# 2) Instalar Node Exporter

NODE_VER="1.6.1"
NODE_TAR="node_exporter-${NODE_VER}.linux-amd64.tar.gz"
NODE_URL="https://github.com/prometheus/node_exporter/releases/download/v${NODE_VER}/${NODE_TAR}"

cd /tmp
if [ ! -f "/tmp/${NODE_TAR}" ]; then
  wget -q "${NODE_URL}" -O "/tmp/${NODE_TAR}"
fi

tar xzf "/tmp/${NODE_TAR}" -C /tmp
NODE_DIR=$(tar -tf "/tmp/${NODE_TAR}" | head -1 | cut -f1 -d"/")

cp "/tmp/${NODE_DIR}/node_exporter" /usr/local/bin/
useradd --no-create-home --shell /usr/sbin/nologin node_exporter || true
mkdir -p /var/lib/node_exporter
chown node_exporter:node_exporter /var/lib/node_exporter


# 3) Crear servicio systemd

cat > /etc/systemd/system/node_exporter.service <<'EOF'
[Unit]
Description=Node Exporter
Wants=network-online.target
After=network-online.target

[Service]
User=node_exporter
Group=node_exporter
Type=simple
ExecStart=/usr/local/bin/node_exporter

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable node_exporter
systemctl restart node_exporter
